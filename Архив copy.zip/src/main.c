#include "minilib.h"

#define NAME_WINDOW "Hello World"

#define WINDOW_X 800 // width
#define WINDOW_Y 600 // height

void create_window()
{

}

int main()
{
    create_window();
    return 0;
}
